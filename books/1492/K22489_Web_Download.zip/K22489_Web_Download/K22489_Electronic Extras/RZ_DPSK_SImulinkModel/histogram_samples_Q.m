close all; clear Q_samples;

delay_time_Tx_Rx = delay_time_Tx_Rx(length(delay_time_Tx_Rx));
Q_samples = demodsignals(delay_time_Tx_Rx+2:length(demodsignals));
x0_1 = -3.5:0.001:3.5;
figure(1);
hist(Q_samples,x0_1);
grid on


   


