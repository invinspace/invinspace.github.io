clear  Q_simple BER_simple varied_threshold index_bit1 index_bit0 ...
       mean_bit1 mean_bit0 std_bit1 std_bit0;
%--------------------------------------------
Q_simple = 0; % Initialise Q value
% Simple Q-factor calculation with assumption: 
% Gaussian Noise  distribution
%--------------------------------------------

Thres_Volt = 0;

% Determine Mean value of samples for bit 1 
index_bit1 = find(Q_samples < Thres_Volt);
samples_bit1 = Q_samples(index_bit1);
mean_bit1 = mean(samples_bit1);
std_bit1 = std(samples_bit1);

% Determine Mean value of samples for bit 0 
index_bit0 = find(Q_samples > Thres_Volt);
samples_bit0 = Q_samples(index_bit0);
mean_bit0 = mean(samples_bit0);
std_bit0 = std(samples_bit0);

% Calculation of Q-factor and BER
% Assumption: Gaussian approximation for the distributions of samples of
% bit 1 and bit 0
Q_simple = abs((mean_bit1 - mean_bit0))/(std_bit1 + std_bit0)
BER_simple = 1/2*(erfc(Q_simple/sqrt(2)))



