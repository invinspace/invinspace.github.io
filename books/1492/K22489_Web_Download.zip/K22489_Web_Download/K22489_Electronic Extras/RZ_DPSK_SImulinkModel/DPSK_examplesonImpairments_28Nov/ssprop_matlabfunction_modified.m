% This function solves the nonlinear Schrodinger equation for
% pulse propagation in an optical fiber using the split-step
% Fourier method described in: 

% Agrawal, Govind.  Nonlinear Fiber Optics, 2nd ed.  Academic
% Press, 1995, Chapter 2 
% 
% The following effects are included in the model: group velocity
% dispersion (GVD), higher order dispersion, loss, and self-phase
% modulation (gamma).
% 
% USAGE
%
% u1 = ssprop(u0,dt,dz,nz,alpha,betap,gamma);
% u1 = ssprop(u0,dt,dz,nz,alpha,betap,gamma,maxiter);
% u1 = ssprop(u0,dt,dz,nz,alpha,betap,gamma,maxiter,tol);
%
% INPUT
%
% u0 - starting field amplitude (vector)
% dt - time step - [in ps]
% dz - propagation stepsize - [in km]
% nz - number of steps to take, ie, ztotal = dz*nz
% alpha - power loss coefficient [in dB/km], need to convert to linear to have P=P0*exp(-alpha*z)
% betap - dispersion polynomial coefs, [beta_0 ... beta_m] [in ps^(m-1)/km]
% gamma - nonlinearity coefficient [in (km^-1.W^-1)]
% maxiter - max number of iterations (default = 4)
% tol - convergence tolerance (default = 1e-5)
%
% OUTPUT
%
% u1 - field at the output
%

function output = ssprop_matlabfunction_modified(input)

nt = input(1);
u0 = input(2:nt+1);
dt = input(nt+2);
dz = input(nt+3);
nz = input(nt+4);
alpha_indB = input(nt+5);
betap = input(nt+6:nt+9);
gamma = input(nt+10);
P_non_thres = input(nt+11)
maxiter = input(nt+12);
tol = input(nt+13);

tic;

%---------------
% Convert alpha_indB to alpha in linear domain
%---------------
alpha = log(10)*alpha_indB/10;          % alpha (1/m)
%---------------

ntt = length(u0);

w = 2*pi*[(0:ntt/2-1),(-ntt/2:-1)]'/(dt*ntt);
%w = 2*pi*[(ntt/2:ntt-1),(1:ntt/2)]'/(dt*ntt);

clear halfstep

halfstep = -alpha/2;
for ii = 0:length(betap)-1;
  halfstep = halfstep - j*betap(ii+1)*(w.^ii)/factorial(ii);
end

clear LinearOperator 
% Linear Operator in Split Step method
LinearOperator = halfstep;
% pause
halfstep = exp(halfstep*dz/2);


u1 = u0;
u0 = u0.*rectwin(ntt);       % rectangular window
ufft = fft(u0);


% Nonlinear operator will be added if the peak power is greater than the
% Nonlinear threshold  
iz = 0;
while (iz < nz) & (max((abs(u1).^2 + abs(u0).^2)) > P_non_thres)
  iz = iz+1;

  uhalf = ifft(halfstep.*ufft);
   
%   angle_ifft_test = angle(ifft(ufft))
%   pause
  
  for ii = 1:maxiter,
    uv = uhalf .* exp(-j*gamma*(abs(u1).^2 + abs(u0).^2)*dz/2);
   
    uv = uv.*rectwin(ntt);       % rectangular window to migitate effects of Gibb phenomenon
%   uv = uv.*tukeywin(ntt,0.3);  % Tapped cosine window
%   uv = uv.*rectwin(ntt);       % rectangular window 
    ufft = halfstep.*fft(uv);
    uv = ifft(ufft);
 
    fprintf('You are using SSFM\n');
    
    if (max(uv-u1)/max(u1) < tol)
      u1 = uv;
      break;
    else
      u1 = uv;
    end
  end
  if (ii == maxiter)
    warning(sprintf('Failed to converge to %f in %d iterations',...
        tol,maxiter));
  end
  
  u0 = u1;

end

if (iz < nz) & (max((abs(u1).^2 + abs(u0).^2)) < P_non_thres)
   
   u1 = u1.*rectwin(ntt);  
   ufft == fft(u1);
   ufft = ufft.*exp(LinearOperator*(nz-iz)*dz);
   u1 = ifft(ufft);
  
   fprintf('Implementing Linear Transfer Function of the Fibre Propagation');
end

toc;
output = u1;   
